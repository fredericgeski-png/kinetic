module kineticmonitor

go 1.21
