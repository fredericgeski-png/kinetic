package kineticmonitor

import (
	"bytes"
	"encoding/json"
	"math"
	"net/http"
	"time"
)

type KineticMonitor struct {
	AgentID  string
	Endpoint string
	History  []float64
	SDKType  string
}

func NewKineticMonitor(agentID, endpoint string) *KineticMonitor {
	if endpoint == "" {
		endpoint = "http://localhost:5000"
	}
	return &KineticMonitor{
		AgentID:  agentID,
		Endpoint: endpoint,
		History:  make([]float64, 0, 10),
		SDKType:  "go",
	}
}

func (m *KineticMonitor) calculateEntropy(text string) float64 {
	if len(text) == 0 {
		return 0
	}
	freq := make(map[rune]float64)
	for _, char := range text {
		freq[char]++
	}
	entropy := 0.0
	length := float64(len(text))
	for _, count := range freq {
		p := count / length
		entropy -= p * math.Log2(p)
	}
	return entropy
}

func (m *KineticMonitor) CheckLoop(context string) bool {
	entropy := m.calculateEntropy(context)
	m.History = append(m.History, entropy)
	if len(m.History) > 10 {
		m.History = m.History[1:]
	}

	loopDetected := false
	if len(m.History) == 10 {
		sum := 0.0
		for _, v := range m.History {
			sum += v
		}
		mean := sum / 10
		variance := 0.0
		for _, v := range m.History {
			variance += (v - mean) * (v - mean)
		}
		variance /= 10
		if variance < 0.01 {
			loopDetected = true
		}
	}

	waste := 0
	if loopDetected {
		waste = 5
	}

	payload := map[string]interface{}{
		"agentId":        m.AgentID,
		"sdkType":        m.SDKType,
		"loopDetected":   loopDetected,
		"autoTerminated": loopDetected,
		"entropyScore":   entropy,
		"wastePrevented": waste,
	}

	jsonPayload, _ := json.Marshal(payload)
	
	go func() {
		client := http.Client{Timeout: 2 * time.Second}
		req, _ := http.NewRequest("POST", m.Endpoint+"/api/v1/telemetry", bytes.NewBuffer(jsonPayload))
		req.Header.Set("Content-Type", "application/json")
		client.Do(req)
	}()

	return loopDetected
}
