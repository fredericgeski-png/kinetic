from setuptools import setup, find_packages

setup(
    name="kinetic_monitor",
    version="0.1.0",
    packages=find_packages(),
    install_requires=["requests"],
    description="Python SDK for Kinetic Integrity Monitor",
)
