import requests
import json
import time
from collections import deque
import math

class KineticMonitor:
    def __init__(self, agent_id: str, endpoint: str = "http://localhost:5000"):
        self.agent_id = agent_id
        self.endpoint = endpoint
        self.history = deque(maxlen=10)
        self.sdk_type = "python"
        
    def _calculate_entropy(self, text: str) -> float:
        if not text:
            return 0.0
        frequencies = {}
        for char in text:
            frequencies[char] = frequencies.get(char, 0) + 1
        
        entropy = 0
        length = len(text)
        for count in frequencies.values():
            p = count / length
            entropy -= p * math.log2(p)
        return entropy

    def check_loop(self, context: str) -> bool:
        entropy = self._calculate_entropy(context)
        self.history.append(entropy)
        
        loop_detected = False
        if len(self.history) == 10:
            # Simple heuristic: if entropy variance is very low over 10 steps, it might be a loop
            variance = sum((x - sum(self.history)/10) ** 2 for x in self.history) / 10
            if variance < 0.01:
                loop_detected = True

        try:
            requests.post(f"{self.endpoint}/api/v1/telemetry", json={
                "agentId": self.agent_id,
                "sdkType": self.sdk_type,
                "loopDetected": loop_detected,
                "autoTerminated": loop_detected,
                "entropyScore": entropy,
                "wastePrevented": 5 if loop_detected else 0
            }, timeout=2)
        except Exception as e:
            pass # Offline queuing could be implemented here

        return loop_detected
