const http = require('http');
const https = require('https');

class KineticMonitor {
    constructor(agentId, endpoint = "http://localhost:5000") {
        this.agentId = agentId;
        this.endpoint = endpoint;
        this.history = [];
        this.sdkType = "nodejs";
    }

    _calculateEntropy(text) {
        if (!text) return 0;
        const frequencies = {};
        for (let i = 0; i < text.length; i++) {
            const char = text[i];
            frequencies[char] = (frequencies[char] || 0) + 1;
        }
        let entropy = 0;
        const len = text.length;
        for (const char in frequencies) {
            const p = frequencies[char] / len;
            entropy -= p * Math.log2(p);
        }
        return entropy;
    }

    async checkLoop(context) {
        const entropy = this._calculateEntropy(context);
        this.history.push(entropy);
        if (this.history.length > 10) this.history.shift();

        let loopDetected = false;
        if (this.history.length === 10) {
            const mean = this.history.reduce((a, b) => a + b) / 10;
            const variance = this.history.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / 10;
            if (variance < 0.01) {
                loopDetected = true;
            }
        }

        const payload = JSON.stringify({
            agentId: this.agentId,
            sdkType: this.sdkType,
            loopDetected,
            autoTerminated: loopDetected,
            entropyScore: entropy,
            wastePrevented: loopDetected ? 5 : 0
        });

        try {
            const url = new URL(`${this.endpoint}/api/v1/telemetry`);
            const client = url.protocol === 'https:' ? https : http;
            
            const req = client.request(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(payload)
                }
            });
            
            req.on('error', () => { /* ignore */ });
            req.write(payload);
            req.end();
        } catch (e) {
            // Offline queuing
        }

        return loopDetected;
    }
}

module.exports = KineticMonitor;
